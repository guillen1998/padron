package com.denis.padron.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PadronViewModel : ViewModel() {

    private val repository = PadronRepository()

    private val _tsjeState = MutableStateFlow<PadronState>(PadronState.Idle)
    val tsjeState: StateFlow<PadronState> = _tsjeState.asStateFlow()

    private val _anrState = MutableStateFlow<PadronState>(PadronState.Idle)
    val anrState: StateFlow<PadronState> = _anrState.asStateFlow()

    private val _plraState = MutableStateFlow<PadronState>(PadronState.Idle)
    val plraState: StateFlow<PadronState> = _plraState.asStateFlow()

    fun consultarTsje(cedula: String) {
        if (cedula.isBlank()) return
        _tsjeState.value = PadronState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            _tsjeState.value = repository.consultarTsje(cedula.trim())
        }
    }

    fun consultarAnr(cedula: String) {
        if (cedula.isBlank()) return
        _anrState.value = PadronState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            _anrState.value = repository.consultarAnr(cedula.trim())
        }
    }

    fun consultarPlra(cedula: String, fechaNacimiento: String = "") {
        if (cedula.isBlank()) return
        _plraState.value = PadronState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            _plraState.value = repository.consultarPlra(cedula.trim(), fechaNacimiento.trim())
        }
    }

    fun resetTsje() { _tsjeState.value = PadronState.Idle }
    fun resetAnr()  { _anrState.value  = PadronState.Idle }
    fun resetPlra() { _plraState.value = PadronState.Idle }
}
