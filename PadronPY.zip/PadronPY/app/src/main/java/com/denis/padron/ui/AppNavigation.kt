package com.denis.padron.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.denis.padron.data.PadronViewModel

@Composable
fun AppNavigation(viewModel: PadronViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                onNavigateToTsje = { navController.navigate("tsje") },
                onNavigateToAnr  = { navController.navigate("anr")  },
                onNavigateToPlra = { navController.navigate("plra") }
            )
        }
        composable("tsje") {
            TsjeScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }
        composable("anr") {
            AnrScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }
        composable("plra") {
            PlraScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }
    }
}
