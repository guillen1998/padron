package com.denis.padron.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onNavigateToTsje = { navController.navigate("tsje") },
                onNavigateToAnr  = { navController.navigate("anr")  },
                onNavigateToPlra = { navController.navigate("plra") }
            )
        }
        composable("tsje") { TsjeScreen(onBack = { navController.popBackStack() }) }
        composable("anr")  { AnrScreen(onBack  = { navController.popBackStack() }) }
        composable("plra") { PlraScreen(onBack = { navController.popBackStack() }) }
    }
}
