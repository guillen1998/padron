package com.denis.padron.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.denis.padron.data.PadronState
import kotlin.math.cos
import kotlin.math.sin

// ─── Paraguay map logo (Canvas-drawn) ────────────────────────────────────────

@Composable
fun ParaguayMapLogo(size: Dp = 52.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        val mapPath = Path().apply {
            moveTo(0.06f * w, 0.12f * h)
            lineTo(0.64f * w, 0.05f * h)
            lineTo(0.97f * w, 0.22f * h)
            lineTo(0.95f * w, 0.76f * h)
            lineTo(0.80f * w, 0.96f * h)
            lineTo(0.42f * w, 0.97f * h)
            lineTo(0.13f * w, 0.83f * h)
            lineTo(0.04f * w, 0.46f * h)
            close()
        }

        drawPath(mapPath, color = Color(0xFFD52B1E).copy(alpha = 0.92f))

        val chacoPath = Path().apply {
            moveTo(0.06f * w, 0.12f * h)
            lineTo(0.51f * w, 0.05f * h)
            quadraticTo(0.47f * w, 0.51f * h, 0.44f * w, 0.97f * h)
            lineTo(0.42f * w, 0.97f * h)
            lineTo(0.13f * w, 0.83f * h)
            lineTo(0.04f * w, 0.46f * h)
            close()
        }
        drawPath(chacoPath, color = Color(0xFF002B7F).copy(alpha = 0.80f))

        val bandPath = Path().apply {
            moveTo(0.04f * w, 0.47f * h)
            lineTo(0.95f * w, 0.47f * h)
            lineTo(0.95f * w, 0.56f * h)
            lineTo(0.04f * w, 0.56f * h)
            close()
        }
        drawPath(bandPath, color = Color.White.copy(alpha = 0.22f))

        val riverPath = Path().apply {
            moveTo(0.51f * w, 0.05f * h)
            quadraticTo(0.47f * w, 0.51f * h, 0.44f * w, 0.97f * h)
        }
        drawPath(riverPath, color = Color.White.copy(alpha = 0.75f), style = Stroke(width = 1.8.dp.toPx()))
        drawPath(mapPath, color = Color.White.copy(alpha = 0.55f), style = Stroke(width = 1.5.dp.toPx()))

        val cx = 0.70f * w
        val cy = 0.52f * h
        val rOuter = 0.085f * w
        val rInner = 0.038f * w
        val starPath = Path().apply {
            for (i in 0 until 5) {
                val outerAngle = Math.toRadians(-90.0 + i * 72.0)
                val innerAngle = Math.toRadians(-90.0 + i * 72.0 + 36.0)
                val ox = (cx + rOuter * cos(outerAngle)).toFloat()
                val oy = (cy + rOuter * sin(outerAngle)).toFloat()
                val ix = (cx + rInner * cos(innerAngle)).toFloat()
                val iy = (cy + rInner * sin(innerAngle)).toFloat()
                if (i == 0) moveTo(ox, oy) else lineTo(ox, oy)
                lineTo(ix, iy)
            }
            close()
        }
        drawPath(starPath, color = Color.White)
    }
}

// ─── App Header ───────────────────────────────────────────────────────────────

@Composable
fun AppHeader() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x99383838))
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ParaguayMapLogo(size = 52.dp)
            Column {
                Text(
                    text = "Padrón General",
                    color = Color.White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                )
                Text(
                    text = "del Paraguay  •  2026",
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 13.sp,
                    letterSpacing = 0.2.sp
                )
            }
        }
    }
}

// ─── Sub-screen header ────────────────────────────────────────────────────────

@Composable
fun PadronScreenHeader(
    title: String,
    subtitle: String,
    accentColor: Color,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x99383838))
            .padding(horizontal = 4.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver",
                    tint = Color.White
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = accentColor,
                    fontSize = 12.sp
                )
            }
        }
    }
}

// ─── Search card ──────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchCard(
    cedula: String,
    onCedulaChange: (String) -> Unit,
    onSearch: () -> Unit,
    isLoading: Boolean,
    accentColor: Color,
    extraContent: (@Composable ColumnScope.() -> Unit)? = null
) {
    val focusManager = LocalFocusManager.current

    val doSearch = {
        focusManager.clearFocus()
        onSearch()
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = cedula,
                onValueChange = { if (it.length <= 12) onCedulaChange(it.filter { c -> c.isDigit() }) },
                label = { Text("Número de Cédula") },
                placeholder = { Text("Ej: 1234567") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = accentColor)
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accentColor,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                    focusedLabelColor = accentColor,
                    unfocusedLabelColor = Color.White.copy(alpha = 0.6f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = accentColor,
                    focusedPlaceholderColor = Color.White.copy(alpha = 0.35f),
                    unfocusedPlaceholderColor = Color.White.copy(alpha = 0.35f)
                ),
                shape = RoundedCornerShape(14.dp)
            )

            extraContent?.let { it() }

            Button(
                onClick = doSearch,
                enabled = cedula.isNotBlank() && !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    disabledContainerColor = accentColor.copy(alpha = 0.4f)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Consultando…", color = Color.White, fontWeight = FontWeight.Bold)
                } else {
                    Text("Consultar", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ─── Results section ──────────────────────────────────────────────────────────

@Composable
fun PadronResultSection(state: PadronState, accentColor: Color) {
    AnimatedContent(
        targetState = state,
        transitionSpec = { fadeIn(initialAlpha = 0f) togetherWith fadeOut() },
        label = "result_transition"
    ) { currentState ->
        when (currentState) {
            is PadronState.Idle    -> Box(modifier = Modifier.fillMaxWidth())
            is PadronState.Loading -> LoadingBox(accentColor)
            is PadronState.Success -> ResultCard(result = currentState.result, accentColor = accentColor)
            is PadronState.NotFound -> StatusCard("🔍", "No encontrado", currentState.mensaje, Color(0xFFFFA726))
            is PadronState.Error    -> StatusCard("⚠️", "Error", currentState.mensaje, Color(0xFFEF5350))
        }
    }
}

@Composable
private fun LoadingBox(accentColor: Color) {
    Box(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = accentColor, strokeWidth = 3.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Consultando el padrón…", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }
    }
}

@Composable
fun ResultCard(result: com.denis.padron.data.ConsultaResult, accentColor: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x28FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Box(modifier = Modifier.size(8.dp).background(accentColor, shape = RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Datos encontrados", color = accentColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))
            result.campos.forEach { (label, value) ->
                ResultRow(label = label, value = value)
                Spacer(modifier = Modifier.height(8.dp))
            }
            result.mensajeExtra?.let { extra ->
                Text(
                    text = extra,
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun ResultRow(label: String, value: String) {
    Column {
        Text(
            text = label.uppercase(),
            color = Color.White.copy(alpha = 0.50f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun StatusCard(emoji: String, title: String, message: String, color: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = emoji, fontSize = 40.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = message, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}
