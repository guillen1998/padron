package com.denis.padron.ui

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun AnrScreen(onBack: () -> Unit) {
    var cedula      by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }
    val focusManager = LocalFocusManager.current
    val accentRed    = Color(0xFFCC0000)
    val lightRed     = Color(0xFFFF5252)

    // WebView ANR (SPA JavaScript)
    if (triggerKey > 0) {
        AnrWebView(
            triggerKey  = triggerKey,
            cedula      = cedula,
            onResult    = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound  = { msg    -> padronState = PadronState.NotFound(msg) },
            onError     = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    androidx.compose.foundation.layout.Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0F0404), Color(0xFF1A0808))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x22CC0000), size.width*.65f, Offset(size.width*.85f, size.height*.2f))
            drawCircle(Color(0x16CC0000), size.width*.50f, Offset(size.width*.10f, size.height*.8f))
        }
        androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF8B0000), accentRed, Color(0xFF8B0000)))))

        androidx.compose.foundation.layout.Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title="Padrón ANR",
                subtitle="Asociación Nacional Republicana — Partido Colorado",
                accentColor=lightRed, backgroundColor=Color(0xDDCC0000),
                onBack={ padronState=PadronState.Idle; onBack() }
            )
            androidx.compose.foundation.layout.Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement=Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🟥","Padrón ANR 2026",
                    "Consultá si estás inscripto en el padrón del Partido Colorado y verificá tu seccional.",
                    lightRed)

                SearchCard(
                    cedula=cedula, onCedulaChange={ cedula=it },
                    isLoading=padronState is PadronState.Loading,
                    accentColor=accentRed,
                    onSearch={
                        focusManager.clearFocus()
                        if(cedula.isNotBlank()){ padronState=PadronState.Loading; triggerKey++ }
                    }
                )

                PadronResultSection(state=padronState, accentColor=lightRed)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ── WebView oculto para ANR (SPA JavaScript) ──────────────────────────────────

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun AnrWebView(
    triggerKey : Int,
    cedula     : String,
    onResult   : (List<Pair<String, String>>) -> Unit,
    onNotFound : (String) -> Unit,
    onError    : (String) -> Unit
) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    key(triggerKey) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled  = true
                    settings.userAgentString    =
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

                    var resultHandled = false

                    // Puente JS → Kotlin
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun extractNow() {
                            mainHandler.post {
                                if (resultHandled) return@post
                                val extractJs = buildExtractJs()
                                evaluateJavascript(extractJs) { raw ->
                                    if (!resultHandled) {
                                        resultHandled = true
                                        handleAnrResult(raw, onResult, onNotFound)
                                    }
                                }
                            }
                        }

                        @JavascriptInterface
                        fun notFound(msg: String) {
                            mainHandler.post {
                                if (!resultHandled) {
                                    resultHandled = true
                                    onNotFound(msg)
                                }
                            }
                        }
                    }, "AndroidBridge")

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            // Esperar 3s a que la SPA se inicialice, luego inyectar
                            mainHandler.postDelayed({
                                view.evaluateJavascript(buildFillJs(cedula), null)
                            }, 3000L)

                            // Fallback: extraer después de 22s pase lo que pase
                            mainHandler.postDelayed({
                                if (!resultHandled) {
                                    resultHandled = true
                                    val extractJs = buildExtractJs()
                                    view.evaluateJavascript(extractJs) { raw ->
                                        handleAnrResult(raw, onResult, onNotFound)
                                    }
                                }
                            }, 22000L)
                        }

                        override fun onReceivedError(
                            view: WebView, request: WebResourceRequest, error: WebResourceError
                        ) {
                            if (request.isForMainFrame && !resultHandled) {
                                resultHandled = true
                                onError("Sin conexión o sitio no disponible")
                            }
                        }
                    }

                    loadUrl("https://www.anr.org.py/padron-2026/")
                }
            },
            modifier = Modifier.size(1.dp, 1.dp)
        )
    }
}

// ── JS para llenar el formulario ANR ─────────────────────────────────────────

private fun buildFillJs(cedula: String) = """
(function(){
  var ci = '$cedula';

  function setNative(el, v) {
    if(!el) return;
    try {
      var s = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if(s && s.set) s.set.call(el, v); else el.value = v;
    } catch(e) { el.value = v; }
    ['focus','input','change','keyup','keydown'].forEach(function(ev) {
      el.dispatchEvent(new Event(ev, {bubbles:true}));
    });
  }

  // Buscar el primer input visible
  var inp = null;
  Array.from(document.querySelectorAll('input')).forEach(function(i) {
    if(!inp && i.type !== 'hidden' && i.type !== 'checkbox' &&
       i.type !== 'radio' && i.type !== 'submit' && i.offsetWidth > 0) {
      inp = i;
    }
  });
  if(inp) setNative(inp, ci);

  // Buscar y hacer click en el botón Consultar
  var btn = null;
  Array.from(document.querySelectorAll('button, input[type=button], input[type=submit]')).forEach(function(b) {
    if(!btn && /consul|buscar|search/i.test((b.textContent||'') + (b.value||''))) btn = b;
  });
  if(!btn) {
    // Último botón visible
    var allBtns = Array.from(document.querySelectorAll('button')).filter(function(b) {
      return b.offsetWidth > 0;
    });
    if(allBtns.length > 0) btn = allBtns[allBtns.length - 1];
  }
  if(btn) {
    setTimeout(function() { btn.click(); }, 500);
  }

  // Intentar llamar funciones globales de consulta
  setTimeout(function() {
    if(typeof consultarPadron === 'function') consultarPadron(ci);
    else if(typeof buscarPadron === 'function') buscarPadron(ci);
    else if(typeof consultar === 'function') consultar(ci);
  }, 800);

  // MutationObserver: esperar que celdas de tabla tengan datos
  var done = false;
  var checks = 0;
  var obs = new MutationObserver(function() {
    if(done) return;
    checks++;

    // Verificar "afiliado no encontrado"
    var bodyText = document.body.textContent.toLowerCase();
    if(bodyText.includes('afiliado no encontrado')) {
      done = true; obs.disconnect();
      window.AndroidBridge.notFound('No encontrado en el Padrón ANR');
      return;
    }

    // Verificar si hay celdas con datos reales (no vacías)
    var cells = document.querySelectorAll('table td');
    var filled = Array.from(cells).filter(function(c) {
      var t = c.textContent.trim();
      return t.length > 0 && !['cedula de identidad','nombres','apellidos','fecha de nacimiento',
             'departamento','distrito','seccional','local','mesa','orden'].includes(t.toLowerCase());
    });
    if(filled.length >= 3) {
      done = true; obs.disconnect();
      setTimeout(function() { window.AndroidBridge.extractNow(); }, 600);
    }

    if(checks > 200) { obs.disconnect(); }
  });
  obs.observe(document.body, {childList:true, subtree:true, characterData:true});

  // Timeout propio del JS (el Kotlin también tiene uno)
  setTimeout(function() {
    if(!done) { done = true; obs.disconnect(); window.AndroidBridge.extractNow(); }
  }, 18000);
})();
""".trimIndent()

// ── JS para extraer resultados de la tabla ANR ────────────────────────────────

private fun buildExtractJs() = """
(function(){
  var results = [];
  var bodyText = document.body ? document.body.textContent.toLowerCase() : '';
  var notFound = bodyText.includes('afiliado no encontrado');

  // La tabla ANR tiene los labels en thead/th y los valores en tbody/td
  var headerCells = document.querySelectorAll('table th, table thead td');
  var dataCells   = document.querySelectorAll('table tbody td');

  var headers = Array.from(headerCells).map(function(h) { return h.textContent.trim(); });
  var values  = Array.from(dataCells).map(function(d)  { return d.textContent.trim(); });

  for(var i = 0; i < Math.min(headers.length, values.length); i++) {
    if(headers[i] && values[i] && values[i].length > 0) {
      results.push([headers[i], values[i]]);
    }
  }

  // Si no hay thead/th, intentar pares de celdas en filas (td de 2 columnas)
  if(!results.length) {
    document.querySelectorAll('table tr').forEach(function(row) {
      var cells = row.querySelectorAll('td');
      if(cells.length >= 2) {
        var k = cells[0].textContent.trim();
        var v = cells[1].textContent.trim();
        if(k && v && k !== v) results.push([k, v]);
      }
    });
  }

  return JSON.stringify({results:results, notFound:notFound});
})();
""".trimIndent()

// ── Parse resultado JSON ──────────────────────────────────────────────────────

private fun handleAnrResult(
    raw      : String?,
    onResult : (List<Pair<String, String>>) -> Unit,
    onNotFound: (String) -> Unit
) {
    if (raw == null) { onNotFound("Sin respuesta del servidor"); return }

    val cleaned = raw.trim().let {
        if (it.startsWith("\"") && it.endsWith("\""))
            it.substring(1, it.length - 1).replace("\\\"","\"").replace("\\n","").replace("\\t","")
        else it
    }

    try {
        val json     = JSONObject(cleaned)
        val notFound = json.optBoolean("notFound", false)
        val arr      = json.optJSONArray("results") ?: JSONArray()

        val campos = mutableListOf<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val pair = arr.optJSONArray(i) ?: continue
            val k    = pair.optString(0, "").trim()
            val v    = pair.optString(1, "").trim()
            if (v.isNotEmpty()) campos.add(k to v)
        }

        when {
            campos.isNotEmpty() -> onResult(campos)
            notFound -> onNotFound("No encontrado en el Padrón ANR")
            else -> onNotFound("No se obtuvieron datos. Verificá la cédula e intentá de nuevo.")
        }
    } catch (e: Exception) {
        onNotFound("Error al procesar respuesta")
    }
}
