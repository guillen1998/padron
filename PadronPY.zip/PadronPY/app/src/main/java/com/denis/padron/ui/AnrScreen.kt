package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

@Composable
fun AnrScreen(onBack: () -> Unit) {
    var cedula      by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }
    val focusManager = LocalFocusManager.current
    val accentRed    = Color(0xFFCC0000)
    val lightRed     = Color(0xFFFF5252)

    // JS: llenar input y click Consultar, luego MutationObserver para tabla AJAX
    fun buildFillJs(ci: String) = """
(function(){
  var ci='$ci';

  function setReactive(el, v){
    if(!el) return;
    try{ Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,v); }
    catch(e){ el.value=v; }
    ['focus','input','change','keyup','keypress'].forEach(function(ev){
      el.dispatchEvent(new Event(ev,{bubbles:true}));
    });
  }

  setTimeout(function(){
    // Buscar input visible (ignorar hidden y checkboxes)
    var inp = null;
    document.querySelectorAll('input').forEach(function(i){
      if(!inp && i.type!=='hidden' && i.type!=='checkbox' && i.type!=='radio' && i.offsetWidth>0)
        inp=i;
    });
    if(inp) setReactive(inp, ci);

    // Click en botón Consultar
    setTimeout(function(){
      var btn = null;
      document.querySelectorAll('button, input[type=button], input[type=submit]').forEach(function(b){
        if(!btn && /consul|buscar|search/i.test(b.textContent+(b.value||''))) btn=b;
      });
      if(!btn) document.querySelectorAll('button, input[type=submit]').forEach(function(b){
        if(!btn) btn=b;
      });
      if(btn) btn.click();
    }, 400);
  }, 2000);

  // MutationObserver: esperar tabla de resultados AJAX
  var done=false;
  var obs=new MutationObserver(function(){
    if(done) return;
    // Buscar fila de tabla con datos (más de 1 celda con texto)
    var rows = document.querySelectorAll('table tbody tr');
    for(var r of rows){
      var cells = r.querySelectorAll('td');
      if(cells.length>=2 && cells[0].textContent.trim().length>0){
        done=true; obs.disconnect();
        setTimeout(function(){ window.AndroidBridge.extractNow(); }, 800);
        break;
      }
    }
  });
  obs.observe(document.body, {childList:true, subtree:true});
  setTimeout(function(){ if(!done){ done=true; obs.disconnect(); window.AndroidBridge.extractNow(); } }, 18000);
})();
    """.trimIndent()

    if (triggerKey > 0) {
        PadronWebView(
            triggerKey = triggerKey,
            url        = "https://www.anr.org.py/pre-padron-2026/",
            fillJs     = buildFillJs(cedula),
            ajaxWaitMs = 18000L,
            onResult   = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound = { msg    -> padronState = PadronState.NotFound(msg) },
            onError    = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0F0404), Color(0xFF1A0808))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x22CC0000), size.width*.65f, Offset(size.width*.85f, size.height*.2f))
            drawCircle(Color(0x16CC0000), size.width*.50f, Offset(size.width*.10f, size.height*.8f))
        }
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF8B0000), accentRed, Color(0xFF8B0000)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title           = "Padrón ANR",
                subtitle        = "Asociación Nacional Republicana — Partido Colorado",
                accentColor     = lightRed,
                backgroundColor = Color(0xDDCC0000),
                onBack          = { padronState = PadronState.Idle; onBack() }
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🟥","Pre-Padrón ANR 2026",
                    "Consultá si estás inscripto en el padrón del Partido Colorado y verificá tu seccional.",
                    lightRed)

                SearchCard(
                    cedula=cedula, onCedulaChange={ cedula=it },
                    isLoading=padronState is PadronState.Loading,
                    accentColor=accentRed,
                    onSearch={
                        focusManager.clearFocus()
                        if(cedula.isNotBlank()){ padronState=PadronState.Loading; triggerKey++ }
                    }
                )

                PadronResultSection(state=padronState, accentColor=lightRed)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
