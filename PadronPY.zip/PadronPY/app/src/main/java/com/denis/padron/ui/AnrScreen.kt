package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.denis.padron.data.PadronState
import com.denis.padron.data.PadronViewModel

@Composable
fun AnrScreen(viewModel: PadronViewModel, onBack: () -> Unit) {
    val state by viewModel.anrState.collectAsStateWithLifecycle()
    var cedula by remember { mutableStateOf("") }

    val accentRed = Color(0xFFCC0000)
    val lightRed  = Color(0xFFFF5252)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F0404), Color(0xFF1A0808), Color(0xFF0F0404))
                )
            )
    ) {
        // Background red glow
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0x22CC0000),
                radius = size.width * 0.65f,
                center = Offset(size.width * 0.85f, size.height * 0.20f)
            )
            drawCircle(
                color = Color(0x16CC0000),
                radius = size.width * 0.50f,
                center = Offset(size.width * 0.10f, size.height * 0.80f)
            )
        }

        // Red top accent line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF8B0000), accentRed, Color(0xFF8B0000))
                    )
                )
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(5.dp))

            PadronScreenHeader(
                title = "Padrón ANR",
                subtitle = "Asociación Nacional Republicana — Partido Colorado",
                accentColor = lightRed,
                onBack = {
                    viewModel.resetAnr()
                    onBack()
                }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                AnrInfoCard(accentRed = accentRed, lightRed = lightRed)

                SearchCard(
                    cedula = cedula,
                    onCedulaChange = { cedula = it },
                    onSearch = { viewModel.consultarAnr(cedula) },
                    isLoading = state is PadronState.Loading,
                    accentColor = accentRed
                )

                PadronResultSection(state = state, accentColor = lightRed)

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun AnrInfoCard(accentRed: Color, lightRed: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x20CC0000)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🟥", style = MaterialTheme.typography.titleLarge)
            Column {
                Text(
                    "Pre-Padrón ANR 2026",
                    color = lightRed,
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    "Consultá si estás inscripto en el padrón del Partido Colorado " +
                            "y verificá tu seccional y zona.",
                    color = Color.White.copy(alpha = 0.65f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
