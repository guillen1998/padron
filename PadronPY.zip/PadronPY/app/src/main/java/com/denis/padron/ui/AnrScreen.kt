package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

@Composable
fun AnrScreen(onBack: () -> Unit) {

    var cedula      by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }

    val focusManager = LocalFocusManager.current
    val accentRed    = Color(0xFFCC0000)
    val lightRed     = Color(0xFFFF5252)

    // JS: fill the single search input and click "Consultar"
    // ANR WordPress site uses AJAX — MutationObserver detects when result table appears
    fun buildFillJs() = """
        (function(){
          var ci = '${cedula}';

          // Find the search input
          var inp = document.querySelector('input[type=text], input[type=search], input[type=number], input:not([type])');
          if(inp){
            try{
              var s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value');
              if(s && s.set) s.set.call(inp, ci); else inp.value = ci;
            }catch(e){ inp.value = ci; }
            ['input','change','keyup'].forEach(function(ev){ inp.dispatchEvent(new Event(ev,{bubbles:true})); });
          }

          // Click the Consultar button
          var btn = null;
          document.querySelectorAll('button, input[type=submit], input[type=button], a[href*="#"]').forEach(function(b){
            if(!btn && /consul|buscar|search/i.test(b.textContent + (b.value||''))) btn = b;
          });
          if(!btn) btn = document.querySelector('button, input[type=submit]');
          if(btn) btn.click();

          // MutationObserver: fires when AJAX injects the result table
          var done = false;
          var obs = new MutationObserver(function(){
            var tbl = document.querySelector('table tbody tr td');
            if(tbl && !done){
              done = true;
              obs.disconnect();
              setTimeout(function(){ window.AndroidBridge.extractNow(); }, 600);
            }
          });
          obs.observe(document.body, {childList:true, subtree:true});

          // Safety fallback (handled by Kotlin timer too)
          setTimeout(function(){ if(!done){ done=true; obs.disconnect(); window.AndroidBridge.extractNow(); } }, 12000);
        })();
    """.trimIndent()

    if (triggerKey > 0) {
        PadronWebView(
            triggerKey = triggerKey,
            url        = "https://www.anr.org.py/pre-padron-2026/",
            fillJs     = buildFillJs(),
            ajaxWaitMs = 12000L,
            onResult   = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound = { msg    -> padronState = PadronState.NotFound(msg) },
            onError    = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0F0404), Color(0xFF1A0808), Color(0xFF0F0404))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x22CC0000), size.width*.65f, Offset(size.width*.85f, size.height*.20f))
            drawCircle(Color(0x16CC0000), size.width*.50f, Offset(size.width*.10f, size.height*.80f))
        }
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF8B0000), accentRed, Color(0xFF8B0000)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title       = "Padrón ANR",
                subtitle    = "Asociación Nacional Republicana — Partido Colorado",
                accentColor = lightRed,
                onBack      = { padronState = PadronState.Idle; onBack() }
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🟥", "Pre-Padrón ANR 2026",
                    "Consultá si estás inscripto en el padrón del Partido Colorado y verificá tu seccional.",
                    lightRed)

                SearchCard(
                    cedula         = cedula,
                    onCedulaChange = { cedula = it },
                    onSearch       = {
                        focusManager.clearFocus()
                        if (cedula.isNotBlank()) {
                            padronState = PadronState.Loading
                            triggerKey++
                        }
                    },
                    isLoading  = padronState is PadronState.Loading,
                    accentColor = accentRed
                )

                PadronResultSection(state = padronState, accentColor = lightRed)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
