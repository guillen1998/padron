package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

// Meses en español para el selector
private val MESES = listOf(
    "Enero","Febrero","Marzo","Abril","Mayo","Junio",
    "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
)

@Composable
fun TsjeScreen(onBack: () -> Unit) {

    var cedula       by remember { mutableStateOf("") }
    var diaSelec     by remember { mutableStateOf(1) }
    var mesSelec     by remember { mutableStateOf(1) }
    var anoText      by remember { mutableStateOf("") }
    var triggerKey   by remember { mutableIntStateOf(0) }
    var padronState  by remember { mutableStateOf<PadronState>(PadronState.Idle) }

    val focusManager = LocalFocusManager.current
    val accentRed    = Color(0xFFD52B1E)

    // Build the JS that fills the TSJE form and submits it
    fun buildFillJs(): String = """
        (function(){
          var ci='${'$'}{cedula}', dia='$diaSelec', mes='$mesSelec', ano='$anoText';
          
          function setVal(el, v){
            if(!el) return;
            try{ var s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value');
                 if(s && s.set) s.set.call(el,v); else el.value=v; }catch(e){ el.value=v; }
            ['input','change'].forEach(function(ev){ el.dispatchEvent(new Event(ev,{bubbles:true})); });
          }
          
          // CI field — try multiple name patterns
          var ciEl = document.querySelector('[name=nrocedula],[name=cedula],[name=ci],[name=numero_cedula],[name=rcp_numero],[name=nro_cedula]');
          if(!ciEl) ciEl = document.querySelector('input[type=text]');
          setVal(ciEl, ci);
          
          // Day dropdown
          var diaEl = document.querySelector('[name=dia],[name=day],[name=nro_dia]');
          if(diaEl){ diaEl.value = dia; diaEl.dispatchEvent(new Event('change',{bubbles:true})); }
          
          // Month dropdown — try number first, then Spanish name
          var mesEl = document.querySelector('[name=mes],[name=month],[name=nro_mes]');
          if(mesEl){
            mesEl.value = mes;
            if(!mesEl.value) mesEl.value = '0'+mes; // zero-padded
            mesEl.dispatchEvent(new Event('change',{bubbles:true}));
          }
          
          // Year field
          var anoEl = document.querySelector('[name=anio],[name=ano],[name=year],[name=a],[name=nro_anio]');
          if(!anoEl){ var all=document.querySelectorAll('input[type=text]'); if(all.length>1) anoEl=all[all.length-1]; }
          setVal(anoEl, ano);
          
          // Submit
          setTimeout(function(){
            var btn = document.querySelector('input[type=submit],button[type=submit]')
                      || document.querySelector('button');
            if(btn) btn.click();
            else { var f=document.querySelector('form'); if(f) f.submit(); }
          }, 300);
        })();
    """.trimIndent()
        .replace("\${cedula}", cedula)

    // WebView — invisible, runs only when triggerKey > 0
    if (triggerKey > 0) {
        PadronWebView(
            triggerKey  = triggerKey,
            url         = "https://padron.tsje.gov.py/",
            fillJs      = buildFillJs(),
            ajaxWaitMs  = 9000L,
            onResult    = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound  = { msg    -> padronState = PadronState.NotFound(msg) },
            onError     = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0A0E1A), Color(0xFF0D1624), Color(0xFF0A0E1A))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x1AD52B1E), size.width*.55f, Offset(0f, size.height*.35f))
            drawCircle(Color(0x1A002B7F), size.width*.55f, Offset(size.width, size.height*.65f))
        }
        // Flag strip
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(accentRed, Color.White, Color(0xFF002B7F)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title       = "Padrón General",
                subtitle    = "Tribunal Superior de Justicia Electoral",
                accentColor = Color(0xFFFF6B6B),
                onBack      = { padronState = PadronState.Idle; onBack() }
            )

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Info card
                InfoCard("🇵🇾", "Padrón Electoral Nacional",
                    "Ingresá tu cédula y fecha de nacimiento para consultar tu local de votación.",
                    accentRed)

                // Search form
                TsjeSearchCard(
                    cedula       = cedula,
                    onCedulaChange = { cedula = it },
                    diaSelec     = diaSelec,
                    onDiaChange  = { diaSelec = it },
                    mesSelec     = mesSelec,
                    onMesChange  = { mesSelec = it },
                    anoText      = anoText,
                    onAnoChange  = { anoText = it },
                    isLoading    = padronState is PadronState.Loading,
                    accentColor  = accentRed,
                    onSearch     = {
                        focusManager.clearFocus()
                        if (cedula.isNotBlank() && anoText.length == 4) {
                            padronState = PadronState.Loading
                            triggerKey++
                        }
                    }
                )

                PadronResultSection(state = padronState, accentColor = accentRed)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TsjeSearchCard(
    cedula: String, onCedulaChange: (String) -> Unit,
    diaSelec: Int,  onDiaChange: (Int) -> Unit,
    mesSelec: Int,  onMesChange: (Int) -> Unit,
    anoText: String, onAnoChange: (String) -> Unit,
    isLoading: Boolean,
    accentColor: Color,
    onSearch: () -> Unit
) {
    var showDiaDrop by remember { mutableStateOf(false) }
    var showMesDrop by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            // CI
            OutlinedTextField(
                value = cedula, onValueChange = { if (it.length <= 12) onCedulaChange(it.filter(Char::isDigit)) },
                label = { Text("Número de Cédula") },
                placeholder = { Text("Ej: 4356137") },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = accentColor) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = tsjeFieldColors(accentColor),
                shape = RoundedCornerShape(14.dp)
            )

            Text("Fecha de Nacimiento", color = Color.White.copy(alpha = .6f), fontSize = 13.sp)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {

                // Día
                Box(Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showDiaDrop = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(.6f))
                    ) { Text("Día: $diaSelec", color = Color.White, fontSize = 13.sp) }
                    DropdownMenu(expanded = showDiaDrop, onDismissRequest = { showDiaDrop = false }) {
                        (1..31).forEach { d ->
                            DropdownMenuItem(text = { Text("$d") }, onClick = { onDiaChange(d); showDiaDrop = false })
                        }
                    }
                }

                // Mes
                Box(Modifier.weight(1.6f)) {
                    OutlinedButton(
                        onClick = { showMesDrop = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(.6f))
                    ) { Text(MESES[mesSelec - 1], color = Color.White, fontSize = 13.sp) }
                    DropdownMenu(expanded = showMesDrop, onDismissRequest = { showMesDrop = false }) {
                        MESES.forEachIndexed { idx, nombre ->
                            DropdownMenuItem(text = { Text(nombre) }, onClick = { onMesChange(idx + 1); showMesDrop = false })
                        }
                    }
                }

                // Año
                OutlinedTextField(
                    value = anoText, onValueChange = { if (it.length <= 4) onAnoChange(it.filter(Char::isDigit)) },
                    label = { Text("Año") },
                    placeholder = { Text("1998") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    singleLine = true,
                    modifier = Modifier.weight(1.3f),
                    colors = tsjeFieldColors(accentColor),
                    shape = RoundedCornerShape(14.dp)
                )
            }

            Button(
                onClick = onSearch,
                enabled = cedula.isNotBlank() && anoText.length == 4 && !isLoading,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    disabledContainerColor = accentColor.copy(alpha = .4f)
                )
            ) {
                Text(
                    if (isLoading) "Consultando…" else "Consultar",
                    color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun tsjeFieldColors(accentColor: Color) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = accentColor,
    unfocusedBorderColor = Color.White.copy(.4f),
    focusedLabelColor    = accentColor,
    unfocusedLabelColor  = Color.White.copy(.6f),
    focusedTextColor     = Color.White,
    unfocusedTextColor   = Color.White,
    cursorColor          = accentColor,
    focusedPlaceholderColor   = Color.White.copy(.35f),
    unfocusedPlaceholderColor = Color.White.copy(.35f)
)

@Composable
internal fun InfoCard(emoji: String, title: String, desc: String, accentColor: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = accentColor.copy(.15f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(emoji, style = MaterialTheme.typography.titleLarge)
            Column {
                Text(title, color = accentColor, style = MaterialTheme.typography.labelLarge)
                Text(desc, color = Color.White.copy(.65f), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
