package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

private val MESES = listOf(
    "Enero","Febrero","Marzo","Abril","Mayo","Junio",
    "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
)

@Composable
fun TsjeScreen(onBack: () -> Unit) {
    var cedula      by remember { mutableStateOf("") }
    var diaSelec    by remember { mutableIntStateOf(1) }
    var mesSelec    by remember { mutableIntStateOf(1) }
    var anoText     by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }
    val focusManager = LocalFocusManager.current
    val accentRed    = Color(0xFFD52B1E)

    // JS robusto: recorre los elementos del formulario por nombre,
    // luego lo envía creando un form propio si hace falta.
    fun buildFillJs(): String {
        val ci  = cedula
        val dia = diaSelec
        val mes = mesSelec
        val ano = anoText
        val mesNombre = MESES[mes - 1].lowercase()

        return """
(function(){
  var ci='$ci', dia='$dia', mes='$mes', mesNom='$mesNombre', ano='$ano';

  function trigEv(el){
    ['focus','input','change','blur'].forEach(function(ev){
      el.dispatchEvent(new Event(ev,{bubbles:true}));
    });
  }
  function setVal(el,v){
    if(!el) return;
    try{ Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,v); }
    catch(e){ el.value=v; }
    trigEv(el);
  }

  // Esperar a que el DOM esté listo
  setTimeout(function(){

    // ─ Método A: recorrer elements del form ─────────────────────────────
    var form = document.querySelector('form');
    var filled = false;
    if(form){
      Array.from(form.elements).forEach(function(el){
        var n=(el.name||'').toLowerCase();
        if(!n) return;
        if(n.includes('cedula')||n.includes('ci')||n==='nro'||n==='numero'||n.includes('rcp')){
          setVal(el, ci); filled=true;
        } else if(n==='dia'||n.includes('_dia')||n.startsWith('dia')){
          el.value=String(dia); trigEv(el);
        } else if(n==='mes'||n.includes('_mes')||n.startsWith('mes')){
          el.value=String(mes);
          if(!el.value){ el.value='0'+mes; }
          if(!el.value){ el.value=mesNom.substring(0,3); } // 'abr'
          if(!el.value){ el.value=mesNom; }                // 'abril'
          trigEv(el);
        } else if(n==='anio'||n==='ano'||n==='year'||n.includes('anio')||n.includes('ano')){
          setVal(el, ano);
        }
      });
    }

    // ─ Método B: por posición si los nombres no matchearon ──────────────
    if(!filled){
      var visibleInputs = Array.from(document.querySelectorAll('input')).filter(function(i){
        return i.type!=='hidden' && i.offsetWidth>0;
      });
      var selects = Array.from(document.querySelectorAll('select')).filter(function(s){ return s.offsetWidth>0; });

      if(visibleInputs.length>0){ setVal(visibleInputs[0], ci); }

      // Selects: [dia, mes, (posible ano)]
      if(selects.length>=1){ selects[0].value=String(dia); trigEv(selects[0]); }
      if(selects.length>=2){
        selects[1].value=String(mes);
        if(!selects[1].value) selects[1].value='0'+mes;
        if(!selects[1].value) selects[1].selectedIndex=mes; // índice 1-based
        trigEv(selects[1]);
      }
      if(selects.length>=3){ selects[2].value=ano; trigEv(selects[2]); }
      else if(visibleInputs.length>1){ setVal(visibleInputs[visibleInputs.length-1], ano); }
    }

    // ─ Enviar ────────────────────────────────────────────────────────────
    setTimeout(function(){
      var btn = document.querySelector('input[type=submit], button[type=submit]')
               || Array.from(document.querySelectorAll('button')).find(function(b){
                    return /buscar|consultar|enviar/i.test(b.textContent+b.value);
                  })
               || document.querySelector('button');
      if(btn){ btn.click(); }
      else {
        // Crear y enviar formulario propio como último recurso
        var f=document.createElement('form');
        f.method='POST'; f.action=window.location.href;
        [['nrocedula',ci],['cedula',ci],['dia',dia],['mes',mes],['anio',ano],['ano',ano]].forEach(function(pair){
          var inp=document.createElement('input');
          inp.type='hidden'; inp.name=pair[0]; inp.value=pair[1];
          f.appendChild(inp);
        });
        document.body.appendChild(f);
        f.submit();
      }
    }, 600);

  }, 2000); // esperar 2 s a que cargue la página
})();
        """.trimIndent()
    }

    if (triggerKey > 0) {
        PadronWebView(
            triggerKey = triggerKey,
            url        = "https://padron.tsje.gov.py/",
            fillJs     = buildFillJs(),
            ajaxWaitMs = 15000L,
            onResult   = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound = { msg    -> padronState = PadronState.NotFound(msg) },
            onError    = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0A0E1A), Color(0xFF0D1624))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x1AD52B1E), size.width*.55f, Offset(0f, size.height*.35f))
            drawCircle(Color(0x1A002B7F), size.width*.55f, Offset(size.width, size.height*.65f))
        }
        // Franja bandera arriba
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(accentRed, Color.White, Color(0xFF002B7F)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            // Header con color rojo (bandera)
            PadronScreenHeader(
                title           = "Padrón General",
                subtitle        = "Tribunal Superior de Justicia Electoral",
                accentColor     = Color(0xFFFF8A80),
                backgroundColor = Color(0xDD8B0000),
                onBack          = { padronState = PadronState.Idle; onBack() }
            )

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🇵🇾","Padrón Electoral Nacional",
                    "Ingresá tu cédula y fecha de nacimiento para consultar tu local de votación.",
                    accentRed)

                TsjeSearchCard(
                    cedula=cedula, onCedulaChange={ cedula=it },
                    diaSelec=diaSelec, onDiaChange={ diaSelec=it },
                    mesSelec=mesSelec, onMesChange={ mesSelec=it },
                    anoText=anoText,  onAnoChange={ anoText=it },
                    isLoading = padronState is PadronState.Loading,
                    accentColor = accentRed,
                    onSearch = {
                        focusManager.clearFocus()
                        if (cedula.isNotBlank() && anoText.length == 4) {
                            padronState = PadronState.Loading
                            triggerKey++
                        }
                    }
                )

                PadronResultSection(state = padronState, accentColor = accentRed)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TsjeSearchCard(
    cedula:String, onCedulaChange:(String)->Unit,
    diaSelec:Int,  onDiaChange:(Int)->Unit,
    mesSelec:Int,  onMesChange:(Int)->Unit,
    anoText:String, onAnoChange:(String)->Unit,
    isLoading:Boolean, accentColor:Color, onSearch:()->Unit
) {
    var showDia by remember { mutableStateOf(false) }
    var showMes by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(20.dp),
        colors   = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
        elevation= CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            OutlinedTextField(
                value=cedula, onValueChange={ if(it.length<=12) onCedulaChange(it.filter(Char::isDigit)) },
                label={ Text("Número de Cédula") }, placeholder={ Text("Ej: 4356137") },
                leadingIcon={ Icon(Icons.Default.Search, null, tint=accentColor) },
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number, imeAction=ImeAction.Next),
                singleLine=true, modifier=Modifier.fillMaxWidth(),
                colors=fieldColors(accentColor), shape=RoundedCornerShape(14.dp)
            )

            Text("Fecha de Nacimiento", color=Color.White.copy(.6f), fontSize=13.sp)

            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                // Día
                Box(Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick={ showDia=true }, modifier=Modifier.fillMaxWidth(),
                        shape=RoundedCornerShape(14.dp),
                        colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White),
                        border=androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(.6f))
                    ) { Text("Día: $diaSelec", color=Color.White, fontSize=13.sp) }
                    DropdownMenu(expanded=showDia, onDismissRequest={ showDia=false }) {
                        (1..31).forEach { d -> DropdownMenuItem(text={ Text("$d") }, onClick={ onDiaChange(d); showDia=false }) }
                    }
                }
                // Mes
                Box(Modifier.weight(1.6f)) {
                    OutlinedButton(
                        onClick={ showMes=true }, modifier=Modifier.fillMaxWidth(),
                        shape=RoundedCornerShape(14.dp),
                        colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White),
                        border=androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(.6f))
                    ) { Text(MESES[mesSelec-1], color=Color.White, fontSize=13.sp) }
                    DropdownMenu(expanded=showMes, onDismissRequest={ showMes=false }) {
                        MESES.forEachIndexed { i, n -> DropdownMenuItem(text={ Text(n) }, onClick={ onMesChange(i+1); showMes=false }) }
                    }
                }
                // Año
                OutlinedTextField(
                    value=anoText, onValueChange={ if(it.length<=4) onAnoChange(it.filter(Char::isDigit)) },
                    label={ Text("Año") }, placeholder={ Text("1998") },
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number, imeAction=ImeAction.Search),
                    keyboardActions=KeyboardActions(onSearch={ onSearch() }),
                    singleLine=true, modifier=Modifier.weight(1.3f),
                    colors=fieldColors(accentColor), shape=RoundedCornerShape(14.dp)
                )
            }

            Button(
                onClick=onSearch,
                enabled=cedula.isNotBlank() && anoText.length==4 && !isLoading,
                modifier=Modifier.fillMaxWidth().height(50.dp),
                shape=RoundedCornerShape(14.dp),
                colors=ButtonDefaults.buttonColors(
                    containerColor=accentColor, disabledContainerColor=accentColor.copy(.4f)
                )
            ) {
                Text(if(isLoading) "Consultando…" else "Consultar",
                    color=Color.White, fontSize=16.sp, fontWeight=FontWeight.Bold)
            }
        }
    }
}
