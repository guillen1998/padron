package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.denis.padron.data.PadronViewModel

@Composable
fun TsjeScreen(viewModel: PadronViewModel, onBack: () -> Unit) {
    val state by viewModel.tsjeState.collectAsStateWithLifecycle()
    var cedula by remember { mutableStateOf("") }

    val accentRed   = Color(0xFFD52B1E)
    val accentBlue  = Color(0xFF002B7F)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A0E1A), Color(0xFF0D1624), Color(0xFF0A0E1A))
                )
            )
    ) {
        // Background glow — flag colors
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0x1AD52B1E),
                radius = size.width * 0.55f,
                center = Offset(0f, size.height * 0.35f)
            )
            drawCircle(
                color = Color(0x1A002B7F),
                radius = size.width * 0.55f,
                center = Offset(size.width, size.height * 0.65f)
            )
        }

        // Paraguay flag strip at top (3 horizontal bands)
        Box(modifier = Modifier.fillMaxWidth().height(5.dp)) {
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(
                        colors = listOf(accentRed, Color.White, accentBlue)
                    )
                )
            )
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(5.dp))

            PadronScreenHeader(
                title = "Padrón General",
                subtitle = "Tribunal Superior de Justicia Electoral",
                accentColor = Color(0xFFFF6B6B),
                onBack = {
                    viewModel.resetTsje()
                    onBack()
                }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Tip info card
                TsjeInfoCard()

                // Search
                SearchCard(
                    cedula = cedula,
                    onCedulaChange = { cedula = it },
                    onSearch = { viewModel.consultarTsje(cedula) },
                    isLoading = state is com.denis.padron.data.PadronState.Loading,
                    accentColor = accentRed
                )

                // Results
                PadronResultSection(state = state, accentColor = accentRed)

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun TsjeInfoCard() {
    androidx.compose.material3.Card(
        modifier = Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = Color(0x18D52B1E)
        ),
        elevation = androidx.compose.material3.CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            androidx.compose.material3.Text("🇵🇾", style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
            Column {
                androidx.compose.material3.Text(
                    "Padrón Electoral Nacional",
                    color = Color.White,
                    style = androidx.compose.material3.MaterialTheme.typography.labelLarge
                )
                androidx.compose.material3.Text(
                    "Ingresá tu número de cédula para consultar tu inscripción y local de votación.",
                    color = Color.White.copy(alpha = 0.65f),
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
