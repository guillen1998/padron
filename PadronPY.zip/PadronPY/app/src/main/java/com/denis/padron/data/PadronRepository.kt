package com.denis.padron.data

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

class PadronRepository {

    private val ua = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // ─── TSJE ─────────────────────────────────────────────────────────────────
    // Paso 1: GET la página → leer nombres de campo reales y valor de opción del mes
    // Paso 2: POST con esos valores exactos

    fun consultarTsje(cedula: String, dia: Int, mes: Int, ano: String): PadronState {
        return try {
            val url = "https://padron.tsje.gov.py/"

            // ── Paso 1: GET ──────────────────────────────────────────────────
            val getResp = client.newCall(
                Request.Builder().url(url).header("User-Agent", ua).build()
            ).execute()
            val formHtml = getResp.body?.string() ?: return PadronState.Error("Sin respuesta del servidor")
            val cookies  = getResp.headers("Set-Cookie").joinToString("; ") { it.split(";")[0] }
            getResp.close()

            val doc = Jsoup.parse(formHtml)

            // Nombre del campo cédula (primer input visible)
            val ciInput  = doc.select("input[type=text], input:not([type])").firstOrNull()
            val ciName   = ciInput?.attr("name")?.takeIf { it.isNotEmpty() } ?: "cedula"

            // Selects: [0]=día [1]=mes [2]=año (o el año puede ser input de texto)
            val selects  = doc.select("select")

            val dayName  = selects.getOrNull(0)?.attr("name")?.takeIf { it.isNotEmpty() } ?: "dia"

            val mesSelect   = selects.getOrNull(1)
            val mesName     = mesSelect?.attr("name")?.takeIf { it.isNotEmpty() } ?: "mes"
            // Leer el value real del option para el mes indicado
            val mesOptions  = mesSelect?.select("option") ?: emptyList()
            val mesesES     = listOf("enero","febrero","marzo","abril","mayo","junio",
                                     "julio","agosto","setiembre","octubre","noviembre","diciembre")
            val targetMes   = mesesES.getOrNull(mes - 1) ?: ""
            val mesValue = mesOptions.firstOrNull { opt ->
                val text = opt.text().lowercase()
                text.startsWith(targetMes.take(3)) || text == targetMes
            }?.attr("value")
                ?: mesOptions.getOrNull(mes)?.attr("value")      // índice 1-based con vacío en pos 0
                ?: mesOptions.getOrNull(mes - 1)?.attr("value")  // índice 0-based
                ?: mes.toString()

            // Año: tercer select o segundo input de texto
            val anoSelect = selects.getOrNull(2)
            val anoName: String
            val anoValue: String
            if (anoSelect != null) {
                anoName  = anoSelect.attr("name").takeIf { it.isNotEmpty() } ?: "anho"
                anoValue = anoSelect.select("option")
                    .firstOrNull { it.attr("value") == ano || it.text() == ano }
                    ?.attr("value") ?: ano
            } else {
                val textInputs = doc.select("input[type=text], input:not([type])")
                val anoInput   = textInputs.getOrNull(1)
                anoName  = anoInput?.attr("name")?.takeIf { it.isNotEmpty() } ?: "anho"
                anoValue = ano
            }

            // CSRF si existe
            val csrf = doc.selectFirst("input[name=_token], input[name=csrf_token]")

            // ── Paso 2: POST ─────────────────────────────────────────────────
            val fb = FormBody.Builder()
                .add(ciName,  cedula)
                .add(dayName, dia.toString())
                .add(mesName, mesValue)
                .add(anoName, anoValue)
            csrf?.let { fb.add(it.attr("name"), it.attr("value")) }

            val postResp = client.newCall(
                Request.Builder()
                    .url(url)
                    .post(fb.build())
                    .header("User-Agent", ua)
                    .header("Referer", url)
                    .apply { if (cookies.isNotEmpty()) header("Cookie", cookies) }
                    .build()
            ).execute()
            val resultHtml = postResp.body?.string() ?: ""
            postResp.close()

            parseHtml(resultHtml)
        } catch (e: Exception) {
            PadronState.Error("Error de conexión: ${e.localizedMessage}")
        }
    }

    // ─── PLRA ─────────────────────────────────────────────────────────────────
    fun consultarPlra(cedula: String, nombre: String = ""): PadronState {
        return try {
            val url = "https://plra.org.py/public/buscar_enrcp.php"

            // GET para leer nombres reales de campos
            val getResp = client.newCall(
                Request.Builder().url(url).header("User-Agent", ua).build()
            ).execute()
            val formHtml = getResp.body?.string() ?: return PadronState.Error("Sin respuesta del servidor")
            val cookies  = getResp.headers("Set-Cookie").joinToString("; ") { it.split(";")[0] }
            getResp.close()

            val doc = Jsoup.parse(formHtml)
            val inputs = doc.select("input[type=text], input[type=number], input:not([type])")

            // PLRA tiene dos inputs: cédula y nombres
            val cedulaName = inputs.getOrNull(0)?.attr("name")?.takeIf { it.isNotEmpty() } ?: "cedula"
            val nombreName = inputs.getOrNull(1)?.attr("name")?.takeIf { it.isNotEmpty() } ?: "nombres"
            val csrf = doc.selectFirst("input[name=_token], input[name=csrf_token]")

            val fb = FormBody.Builder()
            if (cedula.isNotEmpty()) fb.add(cedulaName, cedula)
            else if (nombre.isNotEmpty()) fb.add(nombreName, nombre)
            csrf?.let { fb.add(it.attr("name"), it.attr("value")) }

            val postResp = client.newCall(
                Request.Builder()
                    .url(url)
                    .post(fb.build())
                    .header("User-Agent", ua)
                    .header("Referer", url)
                    .apply { if (cookies.isNotEmpty()) header("Cookie", cookies) }
                    .build()
            ).execute()
            val resultHtml = postResp.body?.string() ?: ""
            postResp.close()

            parseHtml(resultHtml)
        } catch (e: Exception) {
            PadronState.Error("Error de conexión: ${e.localizedMessage}")
        }
    }

    // ─── Parser genérico ──────────────────────────────────────────────────────
    private fun parseHtml(html: String): PadronState {
        val doc    = Jsoup.parse(html)
        val campos = mutableListOf<Pair<String, String>>()

        // 1. Tablas clave→valor (típico de sitios de gobierno PHP)
        doc.select("table tr").forEach { row ->
            val cells = row.select("td, th")
            if (cells.size >= 2) {
                val k = cells[0].text().trim().removeSuffix(":").trim()
                val v = cells[1].text().trim()
                if (k.isNotEmpty() && v.isNotEmpty() && k != v && k.length < 60 && v.length < 200)
                    campos.add(k to v)
            }
        }

        // 2. Definition lists
        if (campos.isEmpty()) {
            doc.select("dt").forEach { dt ->
                val dd = dt.nextElementSibling()
                if (dd?.tagName() == "dd") campos.add(dt.text().trim() to dd.text().trim())
            }
        }

        // 3. Tarjeta PLRA: nombre en mayúsculas + badges + info
        if (campos.isEmpty()) {
            doc.select("h1, h2, h3, h4, strong, .card-title").forEach { el ->
                if (el.closest("nav") != null || el.closest("header") != null ||
                    el.closest("footer") != null) return@forEach
                val text = el.text().trim()
                if (text.matches(Regex("[A-ZÁÉÍÓÚÜÑ\\s]{4,}")) && text.split(" ").size >= 2)
                    campos.add("NOMBRE COMPLETO" to text)
            }
            doc.select("[class*=badge],[class*=chip],[class*=tag]").forEach { b ->
                if (b.closest("nav") == null) {
                    val t = b.text().trim()
                    if (t.isNotEmpty() && t.length < 80) campos.add("ESTADO" to t)
                }
            }
            doc.select("p, li, small").forEach { el ->
                if (el.children().size > 0) return@forEach
                val text = el.text().trim()
                if (text.length !in 2..120) return@forEach
                if (text.contains("©") || text.contains("@") ||
                    text.lowercase().let { t ->
                        t.contains("buscá por") || t.contains("consulta del") ||
                        t.contains("sistema plra") || t.contains("todos los derechos")
                    }) return@forEach
                val ci = text.indexOf(":")
                if (ci in 1..40) campos.add(text.substring(0, ci).trim() to text.substring(ci + 1).trim())
                else if (text.all { c -> c.isLetter() || c.isWhitespace() } && text.split(" ").size in 1..5)
                    campos.add("" to text)
            }
        }

        // 4. Detección "no encontrado"
        val bodyText = doc.body()?.text()?.lowercase() ?: ""
        val notFound = listOf("no se encontr","no encontrado","no figura","no registr",
                              "afiliado no encontrado").any { bodyText.contains(it) }

        return when {
            campos.isNotEmpty() -> PadronState.Success(ConsultaResult(campos))
            notFound -> PadronState.NotFound("No encontrado en el padrón")
            else -> PadronState.NotFound("No se obtuvieron datos. Verificá la información ingresada.")
        }
    }
}
