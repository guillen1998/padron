package com.denis.padron.data

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

class PadronRepository {

    private val userAgent = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    // ─── TSJE ────────────────────────────────────────────────────────────────

    fun consultarTsje(cedula: String): PadronState {
        return try {
            val baseUrl = "https://padron.tsje.gov.py/"

            // Paso 1: GET para obtener cookies y token CSRF
            val getReq = Request.Builder()
                .url(baseUrl)
                .header("User-Agent", userAgent)
                .build()
            val getResp = client.newCall(getReq).execute()
            val cookies = extractCookies(getResp.headers("Set-Cookie"))
            val pageHtml = getResp.body?.string() ?: ""
            getResp.close()

            val pageDoc = Jsoup.parse(pageHtml)
            val csrfToken = extractCsrf(pageDoc)

            // Paso 2: POST con cédula
            val formBody = FormBody.Builder()
                .add("ci", cedula)
                .add("cedula", cedula)
                .apply { csrfToken?.let { add("_token", it) } }
                .build()

            val postReq = Request.Builder()
                .url(baseUrl)
                .post(formBody)
                .header("User-Agent", userAgent)
                .header("Referer", baseUrl)
                .header("Origin", "https://padron.tsje.gov.py")
                .apply { if (cookies.isNotEmpty()) header("Cookie", cookies) }
                .build()

            val postResp = client.newCall(postReq).execute()
            val html = postResp.body?.string() ?: ""
            postResp.close()

            parseTsjeResponse(html, cedula)
        } catch (e: Exception) {
            PadronState.Error("Error de conexión: ${e.localizedMessage ?: "Sin respuesta del servidor"}")
        }
    }

    private fun parseTsjeResponse(html: String, cedula: String): PadronState {
        val doc = Jsoup.parse(html)
        val campos = mutableListOf<Pair<String, String>>()

        // Intento 1: tablas con filas etiqueta | valor
        doc.select("table tr").forEach { row ->
            val cells = row.select("td, th")
            if (cells.size >= 2) {
                val label = cells[0].text().trim().removeSuffix(":").trim()
                val value = cells[1].text().trim()
                if (label.isNotEmpty() && value.isNotEmpty() && label != value) {
                    campos.add(label to value)
                }
            }
        }

        // Intento 2: listas de definición
        if (campos.isEmpty()) {
            doc.select("dl").forEach { dl ->
                dl.select("dt").zip(dl.select("dd")).forEach { (dt, dd) ->
                    val label = dt.text().trim()
                    val value = dd.text().trim()
                    if (label.isNotEmpty() && value.isNotEmpty()) {
                        campos.add(label to value)
                    }
                }
            }
        }

        // Intento 3: divs con patrón label:value
        if (campos.isEmpty()) {
            doc.select("div, p, span").forEach { el ->
                val text = el.ownText().trim()
                if (text.contains(":") && text.length < 100) {
                    val idx = text.indexOf(":")
                    val label = text.substring(0, idx).trim()
                    val value = text.substring(idx + 1).trim()
                    if (label.length in 3..40 && value.isNotEmpty()) {
                        campos.add(label to value)
                    }
                }
            }
        }

        return evaluarResultado(campos, doc.body()?.text() ?: "", cedula)
    }

    // ─── ANR ─────────────────────────────────────────────────────────────────

    fun consultarAnr(cedula: String): PadronState {
        return try {
            val baseUrl = "https://www.anr.org.py/pre-padron-2026/"

            val getReq = Request.Builder()
                .url(baseUrl)
                .header("User-Agent", userAgent)
                .build()
            val getResp = client.newCall(getReq).execute()
            val cookies = extractCookies(getResp.headers("Set-Cookie"))
            val pageHtml = getResp.body?.string() ?: ""
            getResp.close()

            val pageDoc = Jsoup.parse(pageHtml)
            val csrfToken = extractCsrf(pageDoc)

            // Algunos formularios ANR usan distintos nombres de campo
            val formBody = FormBody.Builder()
                .add("ci", cedula)
                .add("cedula", cedula)
                .add("documento", cedula)
                .apply { csrfToken?.let { add("_token", it) } }
                .build()

            val postReq = Request.Builder()
                .url(baseUrl)
                .post(formBody)
                .header("User-Agent", userAgent)
                .header("Referer", baseUrl)
                .header("Origin", "https://www.anr.org.py")
                .apply { if (cookies.isNotEmpty()) header("Cookie", cookies) }
                .build()

            val postResp = client.newCall(postReq).execute()
            val html = postResp.body?.string() ?: ""
            postResp.close()

            parseGenericResponse(html, cedula)
        } catch (e: Exception) {
            PadronState.Error("Error de conexión: ${e.localizedMessage ?: "Sin respuesta del servidor"}")
        }
    }

    // ─── PLRA ────────────────────────────────────────────────────────────────

    fun consultarPlra(cedula: String, fechaNacimiento: String = ""): PadronState {
        return try {
            val baseUrl = "https://plra.org.py/public/buscar_enrcp.php"

            val getReq = Request.Builder()
                .url(baseUrl)
                .header("User-Agent", userAgent)
                .build()
            val getResp = client.newCall(getReq).execute()
            val cookies = extractCookies(getResp.headers("Set-Cookie"))
            val pageHtml = getResp.body?.string() ?: ""
            getResp.close()

            val pageDoc = Jsoup.parse(pageHtml)
            val csrfToken = extractCsrf(pageDoc)

            val formBody = FormBody.Builder()
                .add("ci", cedula)
                .add("cedula", cedula)
                .add("documento", cedula)
                .apply {
                    if (fechaNacimiento.isNotBlank()) {
                        add("fecha_nacimiento", fechaNacimiento)
                        add("fnac", fechaNacimiento)
                        add("fec_nac", fechaNacimiento)
                    }
                    csrfToken?.let { add("_token", it) }
                }
                .build()

            val postReq = Request.Builder()
                .url(baseUrl)
                .post(formBody)
                .header("User-Agent", userAgent)
                .header("Referer", baseUrl)
                .header("Origin", "https://plra.org.py")
                .apply { if (cookies.isNotEmpty()) header("Cookie", cookies) }
                .build()

            val postResp = client.newCall(postReq).execute()
            val html = postResp.body?.string() ?: ""
            postResp.close()

            parseGenericResponse(html, cedula)
        } catch (e: Exception) {
            PadronState.Error("Error de conexión: ${e.localizedMessage ?: "Sin respuesta del servidor"}")
        }
    }

    // ─── Parseo genérico ─────────────────────────────────────────────────────

    private fun parseGenericResponse(html: String, cedula: String): PadronState {
        val doc = Jsoup.parse(html)
        val campos = mutableListOf<Pair<String, String>>()

        // Tablas
        doc.select("table tr").forEach { row ->
            val cells = row.select("td, th")
            if (cells.size >= 2) {
                val label = cells[0].text().trim().removeSuffix(":").trim()
                val value = cells[1].text().trim()
                if (label.isNotEmpty() && value.isNotEmpty() && label != value) {
                    campos.add(label to value)
                }
            }
        }

        // Listas de definición
        if (campos.isEmpty()) {
            doc.select("dl dt").forEach { dt ->
                val dd = dt.nextElementSibling()
                val label = dt.text().trim()
                val value = dd?.text()?.trim() ?: ""
                if (label.isNotEmpty() && value.isNotEmpty()) {
                    campos.add(label to value)
                }
            }
        }

        // Divs resultado (Bootstrap cards, panels, etc.)
        if (campos.isEmpty()) {
            doc.select(".card-body, .panel-body, .resultado, .result, .datos, .info-box").forEach { container ->
                container.select("p, div, span, li").forEach { el ->
                    val text = el.ownText().trim()
                    val colonIdx = text.indexOf(":")
                    if (colonIdx in 2..40 && text.length < 120) {
                        val label = text.substring(0, colonIdx).trim()
                        val value = text.substring(colonIdx + 1).trim()
                        if (value.isNotEmpty()) campos.add(label to value)
                    }
                }
            }
        }

        // Párrafos con colon
        if (campos.isEmpty()) {
            doc.select("p, li").forEach { el ->
                val text = el.ownText().trim()
                val colonIdx = text.indexOf(":")
                if (colonIdx in 2..40 && text.length < 120) {
                    val label = text.substring(0, colonIdx).trim()
                    val value = text.substring(colonIdx + 1).trim()
                    if (value.isNotEmpty() && label.any { it.isLetter() }) {
                        campos.add(label to value)
                    }
                }
            }
        }

        return evaluarResultado(campos, doc.body()?.text() ?: "", cedula)
    }

    private fun evaluarResultado(
        campos: List<Pair<String, String>>,
        bodyText: String,
        cedula: String
    ): PadronState {
        val texto = bodyText.lowercase()
        val noEncontrado = listOf(
            "no se encontr", "not found", "sin resultado", "no existe",
            "no registr", "no hay result", "ningún resultado", "no figura"
        ).any { texto.contains(it) }

        return when {
            campos.isNotEmpty() -> PadronState.Success(ConsultaResult(campos))
            noEncontrado -> PadronState.NotFound("Cédula $cedula no encontrada en el padrón")
            else -> PadronState.NotFound("No se obtuvieron datos para la cédula $cedula")
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private fun extractCookies(setCookieHeaders: List<String>): String =
        setCookieHeaders.joinToString("; ") { it.split(";")[0] }

    private fun extractCsrf(doc: Document): String? =
        doc.selectFirst("input[name=_token]")?.attr("value")
            ?: doc.selectFirst("input[name=csrf_token]")?.attr("value")
            ?: doc.selectFirst("meta[name=csrf-token]")?.attr("content")
            ?: doc.selectFirst("input[name=_csrf]")?.attr("value")
}
