package com.denis.padron.ui

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState
import org.json.JSONArray
import org.json.JSONObject

// ─── JavaScript que extrae resultados de cualquier página ────────────────────

private val EXTRACT_JS = """
(function(){
  try {
    var results = [];
    var bodyText = document.body ? document.body.textContent.toLowerCase() : '';
    var notFound = /no se encontr|afiliado no encontrado|no encontrado|no figura|sin resultado|not found/.test(bodyText);

    // 1. Tablas
    document.querySelectorAll('table tr').forEach(function(row){
      var cells = row.querySelectorAll('td, th');
      if(cells.length >= 2){
        var k = cells[0].textContent.trim().replace(':','').trim();
        var v = cells[1].textContent.trim();
        if(k && v && k !== v && k.length < 60 && v.length < 200)
          results.push([k, v]);
      }
    });

    // 2. Definition lists
    if(!results.length){
      document.querySelectorAll('dt').forEach(function(dt){
        var dd = dt.nextElementSibling;
        if(dd && dd.tagName === 'DD')
          results.push([dt.textContent.trim(), dd.textContent.trim()]);
      });
    }

    // 3. Bootstrap-style label/value pairs
    if(!results.length){
      document.querySelectorAll('[class*="row"], [class*="field"], [class*="dato"]').forEach(function(el){
        var lbl = el.querySelector('label, strong, [class*="label"], [class*="key"]');
        var val = el.querySelector('[class*="value"], [class*="val"], p, span');
        if(lbl && val && lbl !== val){
          var k = lbl.textContent.trim().replace(':','');
          var v = val.textContent.trim();
          if(k && v) results.push([k, v]);
        }
      });
    }

    // 4. PLRA style: heading + badges + info lines
    if(!results.length){
      var heading = document.querySelector('h1, h2, h3, .card-title, [class*="nombre"]');
      if(heading){
        var name = heading.textContent.trim();
        if(name.length > 3) results.push(['NOMBRE COMPLETO', name]);
      }
      document.querySelectorAll('[class*="badge"], [class*="chip"], [class*="tag"], [class*="afiliado"]').forEach(function(el){
        var t = el.textContent.trim();
        if(t) results.push(['ESTADO', t]);
      });
      document.querySelectorAll('p, li, small, .detail').forEach(function(el){
        if(el.children.length > 0) return;
        var text = el.textContent.trim();
        if(text.length > 1 && text.length < 150){
          results.push(['', text]);
        }
      });
    }

    // 5. Fallback: colon-separated text nodes
    if(!results.length){
      document.querySelectorAll('td, p, div, span, li').forEach(function(el){
        if(el.children.length > 0) return;
        var text = el.textContent.trim();
        var idx = text.indexOf(':');
        if(idx > 0 && idx < 40 && text.length < 150){
          var k = text.substring(0, idx).trim();
          var v = text.substring(idx + 1).trim();
          if(v) results.push([k, v]);
        }
      });
    }

    return JSON.stringify({results: results, notFound: notFound});
  } catch(e) {
    return JSON.stringify({results: [], notFound: false, error: e.message});
  }
})();
""".trimIndent()

// ─── Composable: hidden WebView ───────────────────────────────────────────────

/**
 * Invisible WebView that loads [url], injects [fillJs] after the first page load
 * to fill the form, then extracts results after the second load (traditional form)
 * or after [ajaxWaitMs] milliseconds (AJAX-based sites).
 *
 * Results are reported via [onResult]. Triggers when [triggerKey] changes.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PadronWebView(
    triggerKey: Int,
    url: String,
    fillJs: String,
    ajaxWaitMs: Long = 7000L,
    onResult: (List<Pair<String, String>>) -> Unit,
    onNotFound: (String) -> Unit,
    onError: (String) -> Unit
) {
    if (triggerKey == 0) return

    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var resultHandled by remember { mutableStateOf(false) }

    key(triggerKey) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                        "AppleWebKit/537.36 (KHTML, like Gecko) " +
                        "Chrome/120.0.0.0 Mobile Safari/537.36"

                    // Bridge so JS can trigger extraction early (AJAX sites)
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun extractNow() {
                            mainHandler.post {
                                if (!resultHandled) {
                                    evaluateJavascript(EXTRACT_JS) { raw ->
                                        handleRawResult(raw, onResult, onNotFound)
                                        resultHandled = true
                                    }
                                }
                            }
                        }
                    }, "AndroidBridge")

                    var pageCount = 0

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            pageCount++
                            when (pageCount) {
                                1 -> {
                                    // Inject form fill + submit JS
                                    view.evaluateJavascript(fillJs, null)

                                    // Fallback AJAX timer
                                    mainHandler.postDelayed({
                                        if (!resultHandled) {
                                            view.evaluateJavascript(EXTRACT_JS) { raw ->
                                                handleRawResult(raw, onResult, onNotFound)
                                                resultHandled = true
                                            }
                                        }
                                    }, ajaxWaitMs)
                                }
                                2 -> {
                                    // Traditional form submission → results page loaded
                                    mainHandler.postDelayed({
                                        if (!resultHandled) {
                                            view.evaluateJavascript(EXTRACT_JS) { raw ->
                                                handleRawResult(raw, onResult, onNotFound)
                                                resultHandled = true
                                            }
                                        }
                                    }, 1500L)
                                }
                            }
                        }

                        override fun onReceivedError(
                            view: WebView,
                            request: WebResourceRequest,
                            error: WebResourceError
                        ) {
                            if (request.isForMainFrame && !resultHandled) {
                                resultHandled = true
                                onError("Sin conexión o sitio no disponible")
                            }
                        }
                    }

                    loadUrl(url)
                }
            },
            modifier = Modifier.size(1.dp, 1.dp)
        )
    }
}

// ─── Parse JSON result from JS ────────────────────────────────────────────────

private fun handleRawResult(
    raw: String?,
    onResult: (List<Pair<String, String>>) -> Unit,
    onNotFound: (String) -> Unit
) {
    if (raw == null) { onNotFound("Sin respuesta del servidor"); return }

    // evaluateJavascript wraps strings in extra quotes — unescape
    val cleaned = raw.trim().let {
        if (it.startsWith("\"") && it.endsWith("\""))
            it.substring(1, it.length - 1).replace("\\\"", "\"").replace("\\n", "")
        else it
    }

    try {
        val json = JSONObject(cleaned)
        val notFound = json.optBoolean("notFound", false)
        val arr = json.optJSONArray("results") ?: JSONArray()

        val campos = mutableListOf<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val pair = arr.getJSONArray(i)
            val k = pair.optString(0, "").trim()
            val v = pair.optString(1, "").trim()
            if (v.isNotEmpty()) campos.add(k to v)
        }

        when {
            campos.isNotEmpty() -> onResult(campos)
            notFound -> onNotFound("No encontrado en el padrón")
            else -> onNotFound("No se obtuvieron datos. Verificá la cédula e intentá de nuevo.")
        }
    } catch (e: Exception) {
        onNotFound("Error al procesar la respuesta: ${e.message}")
    }
}
