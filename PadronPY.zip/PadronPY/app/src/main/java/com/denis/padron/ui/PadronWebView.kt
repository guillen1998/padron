package com.denis.padron.ui

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.*
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState
import org.json.JSONArray
import org.json.JSONObject

// ── JS de extracción genérico ─────────────────────────────────────────────────
// Filtra activamente ruido de UI (títulos de página, pie, redes sociales)
private val EXTRACT_JS = """
(function(){
  try {
    var results = [];
    var bodyText = document.body ? document.body.textContent.toLowerCase() : '';
    var notFound = /no se encontr|afiliado no encontrado|no encontrado|no figura|sin resultado|not found/.test(bodyText);

    // ── 1. Tablas (más confiable para sitios de gobierno) ──────────────────
    document.querySelectorAll('table tr').forEach(function(row){
      var cells = row.querySelectorAll('td, th');
      if(cells.length < 2) return;
      var k = cells[0].textContent.trim().replace(':','').trim();
      var v = cells[1].textContent.trim();
      if(!k || !v || k === v || k.length > 60 || v.length > 200) return;
      // Filtrar ruido (menú, copyright, redes)
      if(/^(inicio|menú|menu|home|facebook|twitter|instagram|tiktok|©|copyright)/i.test(v)) return;
      results.push([k, v]);
    });

    // ── 2. Definition lists ────────────────────────────────────────────────
    if(!results.length){
      document.querySelectorAll('dt').forEach(function(dt){
        var dd = dt.nextElementSibling;
        if(dd && dd.tagName === 'DD') results.push([dt.textContent.trim(), dd.textContent.trim()]);
      });
    }

    // ── 3. Tarjeta de resultado PLRA/ANR (nombre en MAYÚSCULAS + badges) ──
    if(!results.length){
      // Headings que parezcan nombres propios (todo mayúsculas, varias palabras)
      document.querySelectorAll('h1,h2,h3,h4,strong,.card-title,.nombre').forEach(function(el){
        if(el.closest('nav') || el.closest('header') || el.closest('footer')) return;
        var text = el.textContent.trim();
        // Nombre válido: solo letras/espacios en mayúsculas, 2+ palabras, > 4 chars
        if(/^[A-ZÁÉÍÓÚÜÑ\s]{4,}$/.test(text) && text.trim().split(/\s+/).length >= 2){
          results.push(['NOMBRE COMPLETO', text]);
        }
      });
      // Badges de estado (Afiliado, etc.)
      document.querySelectorAll('[class*="badge"],[class*="chip"],[class*="tag"],[class*="pill"]').forEach(function(el){
        if(el.closest('nav') || el.closest('header') || el.closest('footer')) return;
        var text = el.textContent.trim();
        if(text && text.length < 80) results.push(['ESTADO', text]);
      });
      // Líneas informativas de la tarjeta (distrito, mesa, etc.)
      document.querySelectorAll('.card p, .card li, .card small, [class*="result"] p, [class*="dato"] p').forEach(function(el){
        if(el.children.length > 0) return;
        var text = el.textContent.trim();
        if(!text || text.length < 2 || text.length > 120) return;
        if(/copyright|©|autor:|facebook|twitter|instagram|tiktok|linkedin|youtube|todos los derechos|buscá por|consulta del padrón|sistema plra/i.test(text)) return;
        results.push(['', text]);
      });
    }

    // ── 4. Pares clave:valor en párrafos (fallback) ────────────────────────
    if(!results.length){
      document.querySelectorAll('p, li').forEach(function(el){
        if(el.children.length > 0) return;
        var text = el.textContent.trim();
        var idx = text.indexOf(':');
        if(idx > 0 && idx < 40 && text.length < 150){
          var k = text.substring(0,idx).trim();
          var v = text.substring(idx+1).trim();
          if(v && !/copyright|©|autor:|http/i.test(v)) results.push([k, v]);
        }
      });
    }

    return JSON.stringify({results:results, notFound:notFound});
  } catch(e){
    return JSON.stringify({results:[], notFound:false, error:e.message});
  }
})();
""".trimIndent()

// ── Componente WebView oculto ─────────────────────────────────────────────────

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PadronWebView(
    triggerKey : Int,
    url        : String,
    fillJs     : String,
    ajaxWaitMs : Long = 10000L,
    onResult   : (List<Pair<String, String>>) -> Unit,
    onNotFound : (String) -> Unit,
    onError    : (String) -> Unit
) {
    if (triggerKey == 0) return

    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    key(triggerKey) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled  = true
                    settings.domStorageEnabled  = true
                    settings.userAgentString    =
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

                    var resultHandled = false
                    var pageCount     = 0

                    // Puente JS→Kotlin para sitios AJAX
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun extractNow() {
                            mainHandler.post {
                                if (!resultHandled) {
                                    evaluateJavascript(EXTRACT_JS) { raw ->
                                        resultHandled = true
                                        handleRawResult(raw, onResult, onNotFound)
                                    }
                                }
                            }
                        }
                    }, "AndroidBridge")

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, pageUrl: String) {
                            pageCount++
                            when (pageCount) {
                                1 -> {
                                    // Primera carga: inyectar JS para llenar y enviar el formulario
                                    mainHandler.postDelayed({
                                        view.evaluateJavascript(fillJs, null)
                                    }, 1500L)

                                    // Fallback para sitios AJAX (si AndroidBridge no dispara)
                                    mainHandler.postDelayed({
                                        if (!resultHandled) {
                                            view.evaluateJavascript(EXTRACT_JS) { raw ->
                                                resultHandled = true
                                                handleRawResult(raw, onResult, onNotFound)
                                            }
                                        }
                                    }, ajaxWaitMs)
                                }
                                2 -> {
                                    // Segunda carga: página de resultados (formulario tradicional)
                                    mainHandler.postDelayed({
                                        if (!resultHandled) {
                                            view.evaluateJavascript(EXTRACT_JS) { raw ->
                                                resultHandled = true
                                                handleRawResult(raw, onResult, onNotFound)
                                            }
                                        }
                                    }, 2000L)
                                }
                            }
                        }

                        override fun onReceivedError(
                            view: WebView, request: WebResourceRequest, error: WebResourceError
                        ) {
                            if (request.isForMainFrame && !resultHandled) {
                                resultHandled = true
                                onError("Sin conexión o el sitio no está disponible")
                            }
                        }
                    }

                    loadUrl(url)
                }
            },
            modifier = Modifier.size(1.dp, 1.dp)
        )
    }
}

// ── Parseo del JSON devuelto por JS ───────────────────────────────────────────

private fun handleRawResult(
    raw      : String?,
    onResult : (List<Pair<String, String>>) -> Unit,
    onNotFound: (String) -> Unit
) {
    if (raw == null) { onNotFound("Sin respuesta del servidor"); return }

    val cleaned = raw.trim().let {
        if (it.startsWith("\"") && it.endsWith("\""))
            it.substring(1, it.length - 1)
                .replace("\\\"", "\"")
                .replace("\\n", "")
                .replace("\\t", "")
        else it
    }

    try {
        val json     = JSONObject(cleaned)
        val notFound = json.optBoolean("notFound", false)
        val arr      = json.optJSONArray("results") ?: JSONArray()

        val campos = mutableListOf<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val pair = arr.optJSONArray(i) ?: continue
            val k    = pair.optString(0, "").trim()
            val v    = pair.optString(1, "").trim()
            if (v.isNotEmpty()) campos.add(k to v)
        }

        when {
            campos.isNotEmpty() -> onResult(campos)
            notFound            -> onNotFound("No encontrado en el padrón")
            else                -> onNotFound("No se obtuvieron datos. Verificá los datos e intentá de nuevo.")
        }
    } catch (e: Exception) {
        onNotFound("Error al procesar respuesta")
    }
}
