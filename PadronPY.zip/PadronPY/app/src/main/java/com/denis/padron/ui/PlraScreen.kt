package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.denis.padron.data.PadronState
import com.denis.padron.data.PadronViewModel

@Composable
fun PlraScreen(viewModel: PadronViewModel, onBack: () -> Unit) {
    val state by viewModel.plraState.collectAsStateWithLifecycle()
    var cedula by remember { mutableStateOf("") }
    var fechaNacimiento by remember { mutableStateOf("") }

    val accentBlue = Color(0xFF1565C0)
    val lightBlue  = Color(0xFF82B1FF)
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF030B18), Color(0xFF071528), Color(0xFF030B18))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0x221565C0),
                radius = size.width * 0.65f,
                center = Offset(size.width * 0.15f, size.height * 0.20f)
            )
            drawCircle(
                color = Color(0x161565C0),
                radius = size.width * 0.50f,
                center = Offset(size.width * 0.90f, size.height * 0.78f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF0D47A1), accentBlue, Color(0xFF42A5F5))
                    )
                )
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(5.dp))

            PadronScreenHeader(
                title = "Padrón PLRA",
                subtitle = "Partido Liberal Radical Auténtico",
                accentColor = lightBlue,
                onBack = {
                    viewModel.resetPlra()
                    onBack()
                }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                PlraInfoCard(lightBlue = lightBlue)

                SearchCard(
                    cedula = cedula,
                    onCedulaChange = { cedula = it },
                    onSearch = {
                        focusManager.clearFocus()
                        viewModel.consultarPlra(cedula, fechaNacimiento)
                    },
                    isLoading = state is PadronState.Loading,
                    accentColor = accentBlue,
                    extraContent = {
                        FechaNacimientoField(
                            value = fechaNacimiento,
                            onValueChange = { fechaNacimiento = it },
                            accentColor = accentBlue,
                            onDone = {
                                focusManager.clearFocus()
                                viewModel.consultarPlra(cedula, fechaNacimiento)
                            }
                        )
                    }
                )

                PadronResultSection(state = state, accentColor = lightBlue)

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FechaNacimientoField(
    value: String,
    onValueChange: (String) -> Unit,
    accentColor: Color,
    onDone: () -> Unit
) {
    Column {
        Text(
            text = "Fecha de nacimiento (si es requerida)  •  DD/MM/AAAA",
            color = Color.White.copy(alpha = 0.45f),
            style = MaterialTheme.typography.labelSmall
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(8)
                val formatted = buildString {
                    digits.forEachIndexed { i, c ->
                        if (i == 2 || i == 4) append('/')
                        append(c)
                    }
                }
                onValueChange(formatted)
            },
            label = { Text("Fecha de Nacimiento (opcional)") },
            placeholder = { Text("DD/MM/AAAA") },
            leadingIcon = {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = accentColor)
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = { onDone() }),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accentColor,
                unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                focusedLabelColor = accentColor,
                unfocusedLabelColor = Color.White.copy(alpha = 0.6f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = accentColor,
                focusedPlaceholderColor = Color.White.copy(alpha = 0.35f),
                unfocusedPlaceholderColor = Color.White.copy(alpha = 0.35f)
            ),
            shape = RoundedCornerShape(14.dp)
        )
    }
}

@Composable
private fun PlraInfoCard(lightBlue: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x201565C0)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🔵", style = MaterialTheme.typography.titleLarge)
            Column {
                Text(
                    "Registro PLRA",
                    color = lightBlue,
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    "Ingresá tu cédula para consultar tu inscripción. " +
                            "Si el sistema lo requiere, completá también tu fecha de nacimiento.",
                    color = Color.White.copy(alpha = 0.65f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
