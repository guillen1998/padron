package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

@Composable
fun PlraScreen(onBack: () -> Unit) {
    var cedula      by remember { mutableStateOf("") }
    var nombre      by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }
    val focusManager = LocalFocusManager.current
    val accentBlue   = Color(0xFF1565C0)
    val lightBlue    = Color(0xFF82B1FF)

    fun buildFillJs(ci: String, nom: String) = """
(function(){
  var ci='$ci', nombre='$nom';

  function setReactive(el, v){
    if(!el) return;
    try{ Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,v); }
    catch(e){ el.value=v; }
    ['focus','input','change','keyup'].forEach(function(ev){
      el.dispatchEvent(new Event(ev,{bubbles:true}));
    });
  }

  setTimeout(function(){
    var inputs = Array.from(document.querySelectorAll('input')).filter(function(i){
      return i.type!=='hidden' && i.type!=='checkbox' && i.offsetWidth>0;
    });

    if(ci && inputs.length>0){
      setReactive(inputs[0], ci);       // Primer input = cédula
    } else if(nombre && inputs.length>1){
      setReactive(inputs[1], nombre);   // Segundo input = nombre
    } else if(nombre && inputs.length>0){
      setReactive(inputs[0], nombre);
    }

    // Click Buscar
    setTimeout(function(){
      var btn=null;
      document.querySelectorAll('button').forEach(function(b){
        if(!btn && /buscar/i.test(b.textContent)) btn=b;
      });
      if(!btn) btn=document.querySelector('button[type=submit], input[type=submit]');
      if(btn) btn.click();
    }, 400);
  }, 2000);

  // Observer: esperar que aparezca nombre en MAYÚSCULAS o badge "Afiliado"
  var done=false;
  var obs=new MutationObserver(function(){
    if(done) return;
    // Buscar heading con nombre propio (todo mayúsculas, 2+ palabras)
    var found=false;
    document.querySelectorAll('h1,h2,h3,h4,strong').forEach(function(el){
      if(found||done) return;
      var t=el.textContent.trim();
      if(/^[A-ZÁÉÍÓÚÜÑ\s]{4,}$/.test(t) && t.split(/\s+/).length>=2){
        found=true;
      }
    });
    // O buscar badge "Afiliado"
    if(!found){
      document.querySelectorAll('[class*="badge"],[class*="chip"],[class*="tag"]').forEach(function(b){
        if(/afiliado/i.test(b.textContent)) found=true;
      });
    }
    if(found){
      done=true; obs.disconnect();
      setTimeout(function(){ window.AndroidBridge.extractNow(); }, 800);
    }
  });
  obs.observe(document.body,{childList:true,subtree:true});
  setTimeout(function(){ if(!done){ done=true; obs.disconnect(); window.AndroidBridge.extractNow(); } }, 15000);
})();
    """.trimIndent()

    if (triggerKey > 0) {
        PadronWebView(
            triggerKey = triggerKey,
            url        = "https://plra.org.py/public/buscar_enrcp.php",
            fillJs     = buildFillJs(cedula, nombre),
            ajaxWaitMs = 15000L,
            onResult   = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound = { msg    -> padronState = PadronState.NotFound(msg) },
            onError    = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF030B18), Color(0xFF071528))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x221565C0), size.width*.65f, Offset(size.width*.15f, size.height*.2f))
            drawCircle(Color(0x161565C0), size.width*.50f, Offset(size.width*.90f, size.height*.78f))
        }
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0D47A1), accentBlue, Color(0xFF42A5F5)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title           = "Padrón PLRA",
                subtitle        = "Partido Liberal Radical Auténtico",
                accentColor     = lightBlue,
                backgroundColor = Color(0xDD0D47A1),
                onBack          = { padronState = PadronState.Idle; onBack() }
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🔵","Registro PLRA",
                    "Buscá por cédula o por nombre y apellido para consultar tu inscripción en el partido.",
                    lightBlue)

                SearchCard(
                    cedula=cedula,
                    onCedulaChange={ cedula=it; if(it.isNotEmpty()) nombre="" },
                    isLoading=padronState is PadronState.Loading,
                    accentColor=accentBlue,
                    onSearch={
                        focusManager.clearFocus()
                        if(cedula.isNotBlank()||nombre.isNotBlank()){ padronState=PadronState.Loading; triggerKey++ }
                    },
                    extraContent={
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.Center){
                            HorizontalDivider(Modifier.weight(1f).padding(top=8.dp), color=Color.White.copy(.2f))
                            Text("  ó  ", color=Color.White.copy(.4f))
                            HorizontalDivider(Modifier.weight(1f).padding(top=8.dp), color=Color.White.copy(.2f))
                        }
                        OutlinedTextField(
                            value=nombre,
                            onValueChange={ nombre=it; if(it.isNotEmpty()) cedula="" },
                            label={ Text("Nombres y Apellidos") },
                            placeholder={ Text("Ej: García Juan") },
                            leadingIcon={ Icon(Icons.Default.Person, null, tint=accentBlue) },
                            keyboardOptions=KeyboardOptions(
                                keyboardType=KeyboardType.Text,
                                capitalization=KeyboardCapitalization.Words,
                                imeAction=ImeAction.Search
                            ),
                            keyboardActions=KeyboardActions(onSearch={
                                focusManager.clearFocus()
                                if(nombre.isNotBlank()){ padronState=PadronState.Loading; triggerKey++ }
                            }),
                            singleLine=true, modifier=Modifier.fillMaxWidth(),
                            colors=fieldColors(accentBlue), shape=RoundedCornerShape(14.dp)
                        )
                    }
                )

                PadronResultSection(state=padronState, accentColor=lightBlue)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
