package com.denis.padron.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.denis.padron.data.ConsultaResult
import com.denis.padron.data.PadronState

@Composable
fun PlraScreen(onBack: () -> Unit) {

    var cedula      by remember { mutableStateOf("") }
    var nombre      by remember { mutableStateOf("") }
    var triggerKey  by remember { mutableIntStateOf(0) }
    var padronState by remember { mutableStateOf<PadronState>(PadronState.Idle) }

    val focusManager = LocalFocusManager.current
    val accentBlue   = Color(0xFF1565C0)
    val lightBlue    = Color(0xFF82B1FF)

    // PLRA: PHP-based but likely uses Vue/React reactive inputs
    // Try filling both possible fields (cedula OR nombre)
    fun buildFillJs() = """
        (function(){
          var ci     = '${cedula}';
          var nombre = '${nombre}';

          function setReactive(el, v){
            if(!el) return;
            try{
              var s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value');
              if(s && s.set) s.set.call(el, v); else el.value = v;
            }catch(e){ el.value = v; }
            ['input','change','keyup','keydown'].forEach(function(ev){
              el.dispatchEvent(new Event(ev,{bubbles:true}));
            });
          }

          var inputs = document.querySelectorAll('input[type=text], input[type=number], input:not([type])');

          if(ci){
            // First input is usually CI
            var ciEl = document.querySelector('[name=ci],[name=cedula],[name=nrocedula]') || inputs[0];
            setReactive(ciEl, ci);
          } else if(nombre){
            // Second input is usually name — or use CI field empty and name field
            var nomEl = document.querySelector('[name=nombre],[name=nombres],[name=apellido]') || inputs[1] || inputs[0];
            setReactive(nomEl, nombre);
          }

          // Click Buscar
          var btn = null;
          document.querySelectorAll('button').forEach(function(b){
            if(!btn && /buscar/i.test(b.textContent)) btn = b;
          });
          if(!btn) btn = document.querySelector('button[type=submit], input[type=submit]');
          if(btn) btn.click();

          // MutationObserver: detect result card appearing
          var done = false;
          var obs = new MutationObserver(function(){
            var result = document.querySelector('.card:nth-child(2), [class*="result"], [class*="afiliado"], h3, h4');
            if(result && result.textContent.trim().length > 3 && !done){
              done = true; obs.disconnect();
              setTimeout(function(){ window.AndroidBridge.extractNow(); }, 700);
            }
          });
          obs.observe(document.body, {childList:true, subtree:true});
          setTimeout(function(){ if(!done){ done=true; obs.disconnect(); window.AndroidBridge.extractNow(); } }, 10000);
        })();
    """.trimIndent()

    if (triggerKey > 0) {
        PadronWebView(
            triggerKey = triggerKey,
            url        = "https://plra.org.py/public/buscar_enrcp.php",
            fillJs     = buildFillJs(),
            ajaxWaitMs = 10000L,
            onResult   = { campos -> padronState = PadronState.Success(ConsultaResult(campos)) },
            onNotFound = { msg    -> padronState = PadronState.NotFound(msg) },
            onError    = { msg    -> padronState = PadronState.Error(msg) }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF030B18), Color(0xFF071528), Color(0xFF030B18))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x221565C0), size.width*.65f, Offset(size.width*.15f, size.height*.20f))
            drawCircle(Color(0x161565C0), size.width*.50f, Offset(size.width*.90f, size.height*.78f))
        }
        Box(Modifier.fillMaxWidth().height(5.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0D47A1), accentBlue, Color(0xFF42A5F5)))))

        Column(Modifier.fillMaxSize()) {
            Spacer(Modifier.height(5.dp))
            PadronScreenHeader(
                title       = "Padrón PLRA",
                subtitle    = "Partido Liberal Radical Auténtico",
                accentColor = lightBlue,
                onBack      = { padronState = PadronState.Idle; onBack() }
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                InfoCard("🔵", "Registro PLRA",
                    "Buscá por cédula o por nombre y apellido para consultar tu inscripción en el partido.",
                    lightBlue)

                // Search form with CI + name (name is optional/alternative)
                SearchCard(
                    cedula         = cedula,
                    onCedulaChange = { cedula = it; if(it.isNotEmpty()) nombre = "" },
                    onSearch       = {
                        focusManager.clearFocus()
                        if (cedula.isNotBlank() || nombre.isNotBlank()) {
                            padronState = PadronState.Loading
                            triggerKey++
                        }
                    },
                    isLoading   = padronState is PadronState.Loading,
                    accentColor = accentBlue,
                    extraContent = {
                        // Divider "ó"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            HorizontalDivider(Modifier.weight(1f).padding(top=8.dp), color=Color.White.copy(.2f))
                            Text("  ó  ", color=Color.White.copy(.4f))
                            HorizontalDivider(Modifier.weight(1f).padding(top=8.dp), color=Color.White.copy(.2f))
                        }
                        // Name field
                        OutlinedTextField(
                            value = nombre,
                            onValueChange = { nombre = it; if(it.isNotEmpty()) cedula = "" },
                            label = { Text("Nombres y Apellidos") },
                            placeholder = { Text("Ej: García Juan") },
                            leadingIcon = { Icon(Icons.Default.Person, null, tint = accentBlue) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                capitalization = KeyboardCapitalization.Words,
                                imeAction = ImeAction.Search
                            ),
                            keyboardActions = KeyboardActions(onSearch = {
                                focusManager.clearFocus()
                                if (nombre.isNotBlank()) { padronState = PadronState.Loading; triggerKey++ }
                            }),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor        = accentBlue,
                                unfocusedBorderColor      = Color.White.copy(.4f),
                                focusedLabelColor         = accentBlue,
                                unfocusedLabelColor       = Color.White.copy(.6f),
                                focusedTextColor          = Color.White,
                                unfocusedTextColor        = Color.White,
                                cursorColor               = accentBlue,
                                focusedPlaceholderColor   = Color.White.copy(.35f),
                                unfocusedPlaceholderColor = Color.White.copy(.35f)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        )
                    }
                )

                PadronResultSection(state = padronState, accentColor = lightBlue)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
